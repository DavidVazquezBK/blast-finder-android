-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-07-2017 a las 07:24:39
-- Versión del servidor: 10.1.13-MariaDB
-- Versión de PHP: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `blastfinder`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `idCategoria` int(11) NOT NULL,
  `nombre` varchar(15) NOT NULL,
  `iniciales` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `material`
--

CREATE TABLE `material` (
  `idMaterial` int(11) NOT NULL,
  `notas` varchar(60) DEFAULT 'Sin notas',
  `Producto_idProducto` int(11) NOT NULL,
  `nombre` varchar(30) DEFAULT 'Generando'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimiento`
--

CREATE TABLE `movimiento` (
  `idMovimiento` int(11) NOT NULL,
  `Material_idMaterial` int(11) NOT NULL,
  `Ubicacion_idUbicacion` int(11) NOT NULL,
  `fechaHora` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `idProducto` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `Categoria_idCategoria` int(11) NOT NULL,
  `iniciales` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `idUbicacion` int(11) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `descripcion` varchar(60) DEFAULT 'Sin descripción'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ultimomovimiento`
--
CREATE TABLE `ultimomovimiento` (
`idMovimiento` int(11)
,`Material_idMaterial` int(11)
,`Ubicacion_idUbicacion` int(11)
,`fechaHora` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `ultimomovimientonombres`
--
CREATE TABLE `ultimomovimientonombres` (
`id` int(11)
,`material` varchar(30)
,`ubicacion` varchar(20)
,`fechaHora` timestamp
);

-- --------------------------------------------------------

--
-- Estructura para la vista `ultimomovimiento`
--
DROP TABLE IF EXISTS `ultimomovimiento`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ultimomovimiento`  AS  select `movimiento`.`idMovimiento` AS `idMovimiento`,`movimiento`.`Material_idMaterial` AS `Material_idMaterial`,`movimiento`.`Ubicacion_idUbicacion` AS `Ubicacion_idUbicacion`,`movimiento`.`fechaHora` AS `fechaHora` from `movimiento` where `movimiento`.`fechaHora` in (select max(`movimiento`.`fechaHora`) from `movimiento` group by `movimiento`.`Material_idMaterial`) order by `movimiento`.`Material_idMaterial` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `ultimomovimientonombres`
--
DROP TABLE IF EXISTS `ultimomovimientonombres`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ultimomovimientonombres`  AS  select `ultimomovimiento`.`idMovimiento` AS `id`,`material`.`nombre` AS `material`,`ubicacion`.`nombre` AS `ubicacion`,`ultimomovimiento`.`fechaHora` AS `fechaHora` from ((`ultimomovimiento` join `ubicacion`) join `material`) where ((`ubicacion`.`idUbicacion` = `ultimomovimiento`.`Ubicacion_idUbicacion`) and (`material`.`idMaterial` = `ultimomovimiento`.`Material_idMaterial`)) order by `ultimomovimiento`.`fechaHora` desc ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`idCategoria`),
  ADD UNIQUE KEY `nombre_UNIQUE` (`nombre`),
  ADD UNIQUE KEY `iniciales_UNIQUE` (`iniciales`);

--
-- Indices de la tabla `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`idMaterial`),
  ADD KEY `fk_Material_Producto1_idx` (`Producto_idProducto`);

--
-- Indices de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD PRIMARY KEY (`idMovimiento`),
  ADD KEY `fk_Material_has_Ubicacion_Ubicacion1_idx` (`Ubicacion_idUbicacion`),
  ADD KEY `fk_Material_has_Ubicacion_Material1_idx` (`Material_idMaterial`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`idProducto`),
  ADD UNIQUE KEY `nombre_UNIQUE` (`nombre`),
  ADD UNIQUE KEY `iniciales_UNIQUE` (`iniciales`),
  ADD KEY `fk_Material_Categoria1_idx` (`Categoria_idCategoria`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`idUbicacion`),
  ADD UNIQUE KEY `nombre_UNIQUE` (`nombre`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `idCategoria` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `material`
--
ALTER TABLE `material`
  MODIFY `idMaterial` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `movimiento`
--
ALTER TABLE `movimiento`
  MODIFY `idMovimiento` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `idProducto` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `idUbicacion` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `fk_Material_Producto1` FOREIGN KEY (`Producto_idProducto`) REFERENCES `producto` (`idProducto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `movimiento`
--
ALTER TABLE `movimiento`
  ADD CONSTRAINT `fk_Material_has_Ubicacion_Material1` FOREIGN KEY (`Material_idMaterial`) REFERENCES `material` (`idMaterial`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Material_has_Ubicacion_Ubicacion1` FOREIGN KEY (`Ubicacion_idUbicacion`) REFERENCES `ubicacion` (`idUbicacion`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `fk_Material_Categoria1` FOREIGN KEY (`Categoria_idCategoria`) REFERENCES `categoria` (`idCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
